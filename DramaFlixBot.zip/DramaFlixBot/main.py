#!/usr/bin/env python3
import os
import json
import threading
import time
import io
from datetime import datetime, timedelta, timezone
import logging

from flask import Flask, request
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode, InputFile
from telegram.ext import Updater, CommandHandler, CallbackQueryHandler, MessageHandler, Filters, ConversationHandler
import requests
import qrcode
from dotenv import load_dotenv

load_dotenv()

# ---------------- CONFIG / LOG ----------------
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')

TOKEN = os.getenv('TELEGRAM_TOKEN')

try:
    ADMIN_ID = int(os.getenv('ADMIN_ID')) if os.getenv('ADMIN_ID') else None
except Exception:
    ADMIN_ID = None

try:
    CHANNEL_ID = int(os.getenv('CHANNEL_ID')) if os.getenv('CHANNEL_ID') else None
except Exception:
    CHANNEL_ID = None

PUSHINPAY_TOKEN = os.getenv('PUSHINPAY_TOKEN')
DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')
os.makedirs(DATA_DIR, exist_ok=True)

charges_lock = threading.Lock()

# ---------------- FLASK (WEBHOOK) ----------------
app = Flask(__name__)
updater = None  # definido em main

@app.route('/webhook', methods=['GET', 'POST'])
def webhook():
    global updater
    logging.info("WEBHOOK RECEBIDO → %s %s", request.method, request.args or request.get_json())
    bot = updater.bot if updater else None

    # Formato novo → GET
    if request.args.get('status') == 'paid' and request.args.get('id'):
        transaction_id = request.args.get('id')
        with charges_lock:
            for c in charges:
                if c.get('pushin_id') == transaction_id and not c.get('paid'):
                    logging.info("PAGAMENTO CONFIRMADO (GET): %s", transaction_id)
                    try:
                        mark_paid(c['id'], bot)
                    except Exception:
                        logging.exception("Erro ao marcar pago via webhook GET")
                    return 'OK', 200

    # Formato antigo → POST JSON
    if request.is_json:
        data = request.get_json(force=True)
        if data.get('event') in ['charge.paid', 'pix.received', 'payment.paid']:
            transaction_id = data.get('id') or (data.get('data') or {}).get('id')
            if transaction_id:
                with charges_lock:
                    for c in charges:
                        if c.get('pushin_id') == transaction_id and not c.get('paid'):
                            logging.info("PAGAMENTO CONFIRMADO (JSON): %s", transaction_id)
                            try:
                                mark_paid(c['id'], bot)
                            except Exception:
                                logging.exception("Erro ao marcar pago via webhook JSON")
                            return 'OK', 200

    return 'IGNORADO', 200

def run_flask():
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, use_reloader=False)

# =============== ARQUIVOS JSON =============
def load_json(file, default):
    path = os.path.join(DATA_DIR, file)
    if not os.path.exists(path):
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(default, f, indent=2, ensure_ascii=False)
        return default
    with open(path, 'r', encoding='utf-8') as f:
        try:
            return json.load(f)
        except Exception:
            logging.exception("Erro ao ler JSON %s, reescrevendo com default.", file)
            with open(path, 'w', encoding='utf-8') as f2:
                json.dump(default, f2, indent=2, ensure_ascii=False)
            return default

def save_json(file, data):
    path = os.path.join(DATA_DIR, file)
    tmp = path + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception:
        logging.exception("Erro ao salvar JSON %s", file)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

config  = load_json('config.json',  {"welcome_text": "Bem-vindo ao DramaFlix! 🎬\nEscolha seu plano:", "plans": {}, "remarket_minutes": 30, "remarket_message": "Ei! Ainda tá pensando no plano? Posso reenviar o Pix rapidinho 😊"})
welcome = load_json('welcome.json', {"type": None, "file_id": None, "caption": None})
charges = load_json('charges.json', [])

def fmt_price(cents): return f"R${cents//100},{cents%100:02d}"

# =============== CRIAÇÃO DO PIX ===============
def create_charge(plan_key, user):
    plan = config['plans'][plan_key]
    external_id = f"{plan_key}_{user.id}_{int(time.time())}"

    payload = {
        "value": plan['price'],
        "description": f"Plano {plan['label']} - DramaFlix",
        "webhook_url": "https://webhook.site/f7ceaa05-8844-4989-8070-b9b006d6d64f"
    }
    headers = {"Authorization": f"Bearer {PUSHINPAY_TOKEN}"} if PUSHINPAY_TOKEN else {}

    try:
        r = requests.post("https://api.pushinpay.com.br/api/pix/cashIn", json=payload, headers=headers, timeout=10)
        if r.status_code == 200:
            data = r.json()
            record = {
                "id": external_id,
                "tg_id": user.id,
                "plan_key": plan_key,
                "plan_label": plan['label'],
                "price": plan['price'],
                "created_at": int(time.time()),
                "paid": False,
                "pushin_id": data.get('id'),
                "qr_code": data.get('qr_code'),
                "qr_base64": data.get('qr_code_base64'),
                "remarket_sent": False,
                "reminder_sent": False,
                "removed": False
            }
            with charges_lock:
                charges.append(record)
                save_json('charges.json', charges)
            return record
        else:
            logging.warning("PushinPay retornou status %s: %s", r.status_code, r.text)
    except Exception:
        logging.exception("Erro PushinPay:")

    # fallback simulado
    record = {
        "id": external_id,
        "tg_id": user.id,
        "plan_key": plan_key,
        "plan_label": plan['label'],
        "price": plan['price'],
        "created_at": int(time.time()),
        "paid": False,
        "pix_copy": f"000201...SIMULATED_{external_id}",
        "remarket_sent": False,
        "reminder_sent": False,
        "removed": False
    }
    with charges_lock:
        charges.append(record)
        save_json('charges.json', charges)
    return record

# =============== CONFIRMAÇÃO DE PAGAMENTO ===============
def mark_paid(external_id, bot):
    with charges_lock:
        for c in charges:
            if c['id'] == external_id and not c.get('paid'):
                c['paid'] = True
                c['paid_at'] = int(time.time())
                days = config['plans'][c['plan_key']].get('days')
                if days:
                    c['expires_at'] = int((datetime.now(timezone.utc) + timedelta(days=days)).timestamp())
                save_json('charges.json', charges)

                try:
                    if bot is None and updater:
                        bot = updater.bot
                except Exception:
                    pass

                try:
                    if bot and CHANNEL_ID:
                        invite = bot.create_chat_invite_link(CHANNEL_ID, member_limit=1, expire_date=int(time.time() + 7*24*3600))
                        link = invite.invite_link
                        bot.send_message(c['tg_id'], f"Pagamento confirmado! ✅\n\nLink exclusivo (1 uso):\n{link}")
                        def revoke(local_link, local_bot):
                            time.sleep(30)
                            try:
                                local_bot.revoke_chat_invite_link(CHANNEL_ID, local_link)
                            except Exception:
                                pass
                        threading.Thread(target=revoke, args=(link, bot), daemon=True).start()
                    else:
                        if bot:
                            bot.send_message(c['tg_id'], "Pagamento confirmado! ✅")
                except Exception:
                    logging.exception("Erro ao criar/enviar invite link")

                try:
                    nome = None
                    if bot:
                        chat = bot.get_chat(c['tg_id'])
                        nome = getattr(chat, 'username', None) or getattr(chat, 'first_name', None) or str(c['tg_id'])
                    admin_msg = f"Venda Realizada! 💰\n\n{('@' + nome) if nome and str(nome).startswith('@') else nome} comprou {c['plan_label']} por {fmt_price(c['price'])}"
                    if ADMIN_ID and bot:
                        bot.send_message(ADMIN_ID, admin_msg)
                except Exception:
                    logging.exception("Erro ao notificar admin")
                return True
    return False

# =============== SCHEDULER (remarketing + kick) ===============
def scheduler(bot):
    while True:
        now = int(time.time())
        with charges_lock:
            for c in charges:
                try:
                    # === REMARKETING ===
                    if not c.get('paid') and not c.get('remarket_sent'):
                        if now - c.get('created_at', 0) >= config.get('remarket_minutes', 30) * 60:
                            try:
                                bot.send_message(c['tg_id'], config.get('remarket_message', "Ei! Ainda tá pensando no plano? Posso reenviar o Pix rapidinho"))
                            except:
                                pass
                            c['remarket_sent'] = True
                            save_json('charges.json', charges)

                    # === LEMBRETE 24H ANTES ===
                    if c.get('paid') and c.get('expires_at') and not c.get('reminder_sent'):
                        if 0 < c['expires_at'] - now <= 86400:  # 24h antes
                            try:
                                bot.send_message(c['tg_id'], "Seu acesso vence em 24h! Quer renovar?")
                            except:
                                pass
                            c['reminder_sent'] = True
                            save_json('charges.json', charges)

                    # === VENCEU: BANE E DESBANE NA SEQUÊNCIA ===
                    if c.get('paid') and c.get('expires_at') and now >= c['expires_at'] and not c.get('removed'):
                        user_id = c['tg_id']
                        if user_id != ADMIN_ID:
                            try:
                                # Primeiro bane
                                bot.ban_chat_member(CHANNEL_ID, user_id)
                                # Depois desbane (unban) imediatamente
                                bot.unban_chat_member(CHANNEL_ID, user_id)
                                # Opcional: manda mensagem avisando que perdeu o acesso
                                try:
                                    bot.send_message(user_id, "Seu acesso ao DramaFlix expirou.\n\nPara voltar, é só renovar com /start")
                                except:
                                    pass
                            except Exception as e:
                                logging.error(f"Erro ao banir/desbanir user {user_id}: {e}")

                        c['removed'] = True
                        save_json('charges.json', charges)

                except Exception as e:
                    logging.exception(f"Erro no scheduler para charge {c.get('id')}: {e}")

        time.sleep(60)

# =============== COMANDOS DO CLIENTE ===============
def start(update, context):
    keyboard = [[InlineKeyboardButton(f"{v['label']} • {fmt_price(v['price'])}", callback_data=f"plan_{k}")]
                for k, v in config['plans'].items()]
    markup = InlineKeyboardMarkup(keyboard)

    if welcome.get('type') and welcome.get('file_id'):
        caption = welcome.get('caption') or config['welcome_text']
        try:
            if welcome['type'] == 'photo':
                context.bot.send_photo(update.effective_chat.id, welcome['file_id'], caption=caption, reply_markup=markup, parse_mode=ParseMode.HTML)
            else:
                context.bot.send_video(update.effective_chat.id, welcome['file_id'], caption=caption, reply_markup=markup, parse_mode=ParseMode.HTML)
        except Exception:
            logging.exception("Erro ao enviar welcome media")
    else:
        try:
            update.message.reply_text(config['welcome_text'], reply_markup=markup, parse_mode=ParseMode.HTML)
        except Exception:
            logging.exception("Erro ao enviar welcome text")

def suporte(update, context):
    try:
        update.message.reply_text("Suporte rápido aqui ou @SeuSuporte")
    except Exception:
        logging.exception("Erro no comando suporte")

def status(update, context):
    try:
        active = []
        with charges_lock:
            active = [c for c in charges if c['tg_id'] == update.effective_user.id and c.get('paid') and not c.get('removed')]
        if not active:
            update.message.reply_text("Você não tem acesso ativo.\nUse /start para comprar.")
            return
        c = active[-1]
        exp = datetime.fromtimestamp(c['expires_at']).strftime('%d/%m/%Y') if c.get('expires_at') else "Vitalício"
        update.message.reply_text(f"Plano: {c['plan_label']}\nVence em: {exp}")
    except Exception:
        logging.exception("Erro no comando status")

# =============== CALLBACKS (plan + copy) ===============
def callback_plan(update, context):
    query = update.callback_query
    try:
        query.answer()
    except Exception:
        pass

    plan_key = query.data.split('_', 1)[1]
    record = create_charge(plan_key, query.from_user)

    try:
        if query.message:
            query.delete_message()
    except Exception as e:
        logging.debug("Aviso: não foi possível apagar a mensagem do menu: %s", e)

    text = (f"⭐ Você selecionou o seguinte plano:\n\n"
            f"📱 Plano: <b>{record['plan_label']}</b>\n"
            f"💎 Valor: <b>{fmt_price(record['price'])}</b>\n\n"
            f"💠 Pague via Pix Copia e Cola (ou QR Code em alguns bancos):")

    # envia QR (se houver) ou somente texto
    try:
        if record.get('qr_code'):
            try:
                qr = qrcode.QRCode(version=1, box_size=10, border=4)
                qr.add_data(record['qr_code'])
                qr.make(fit=True)
                img = qr.make_image(fill_color="black", back_color="white")
                bio = io.BytesIO()
                img.save(bio, 'PNG')
                bio.seek(0)
                photo = InputFile(bio, filename="qrcode.png")

                context.bot.send_photo(
                    query.message.chat_id,
                    photo,
                    caption=text,
                    parse_mode=ParseMode.HTML,
                    reply_markup=None
                )
            except Exception:
                logging.exception("Erro ao gerar/enviar QR image:")
                context.bot.send_message(chat_id=query.message.chat_id, text=text, parse_mode=ParseMode.HTML)
        else:
            context.bot.send_message(chat_id=query.message.chat_id, text=text, parse_mode=ParseMode.HTML)
    except Exception:
        logging.exception("Erro ao enviar foto/legenda:")

    pix_code = record.get('qr_code') or record.get('pix_copy') or record.get('qr_base64') or ""
    if not pix_code:
        try:
            context.bot.send_message(chat_id=query.message.chat_id, text="Erro: código Pix indisponível. Tente novamente mais tarde.")
        except Exception:
            pass
        return

    # BOTÃO "COPIAR CÓDIGO" — prefer switch_inline_query_current_chat quando cabe
    try:
        if len(pix_code) <= 350:
            keyboard = [[InlineKeyboardButton("COPIAR CÓDIGO", switch_inline_query_current_chat=pix_code)]]
        else:
            keyboard = [[InlineKeyboardButton("COPIAR CÓDIGO", callback_data="copy_pix")]]
    except Exception:
        keyboard = [[InlineKeyboardButton("COPIAR CÓDIGO", callback_data="copy_pix")]]

    markup_code = InlineKeyboardMarkup(keyboard)

    try:
        context.bot.send_message(
            chat_id=query.message.chat_id,
            text=f"<code>{pix_code}</code>",
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True,
            reply_markup=markup_code
        )
    except Exception:
        logging.exception("Erro ao enviar mensagem com o código Pix:")

def copy_pix_callback(update, context):
    query = update.callback_query
    try:
        query.answer()
    except Exception:
        pass

    user_id = query.from_user.id

    with charges_lock:
        user_charges = [c for c in charges if c.get('tg_id') == user_id]

    if not user_charges:
        try:
            query.answer("Não encontrei o código para copiar.", show_alert=True)
        except Exception:
            pass
        return

    candidate = None
    for c in sorted(user_charges, key=lambda x: x.get('created_at', 0), reverse=True):
        if not c.get('paid'):
            candidate = c
            break
    if not candidate:
        candidate = sorted(user_charges, key=lambda x: x.get('created_at', 0), reverse=True)[0]

    pix_code = candidate.get('qr_code') or candidate.get('pix_copy') or candidate.get('qr_base64')
    if not pix_code:
        try:
            query.answer("Código não disponível.", show_alert=True)
        except Exception:
            pass
        return

    try:
        query.answer(f"Código Pix:\n\n{pix_code}", show_alert=True)
    except Exception:
        logging.exception("Erro ao enviar alert no callback copy_pix:")

    try:
        if query.message:
            try:
                query.edit_message_reply_markup(reply_markup=None)
            except Exception:
                pass

            original_text = query.message.caption or query.message.text or ""
            new_text = original_text + "\n\n✅ Código copiado com sucesso!"
            try:
                if query.message.caption is not None:
                    context.bot.edit_message_caption(chat_id=query.message.chat_id,
                                                     message_id=query.message.message_id,
                                                     caption=new_text,
                                                     parse_mode=ParseMode.HTML)
                else:
                    context.bot.edit_message_text(chat_id=query.message.chat_id,
                                                  message_id=query.message.message_id,
                                                  text=new_text,
                                                  parse_mode=ParseMode.HTML)
            except Exception:
                pass
    except Exception:
        logging.exception("Erro ao editar mensagem após copy_pix:")

# =============== ADMIN PANEL (ConversationHandlers) ===============
# States
(EDIT_SELECT, EDIT_NEWPRICE, EDIT_NEWDAYS,
 ADD_KEY, ADD_LABEL, ADD_PRICE, ADD_DAYS,
 REMOVE_SELECT,
 WELCOME_CHOOSE, WELCOME_UPLOAD, WELCOME_TEXT,
 REMARKET_TIME, REMARKET_MESSAGE,
 SUB_PAGING) = range(14)

def admin_only(func):
    def wrapper(update, context):
        user_id = update.effective_user.id
        if user_id != ADMIN_ID:
            try:
                update.message.reply_text("Acesso negado.")
            except Exception:
                pass
            return
        return func(update, context)
    return wrapper

# ---- Editar Preços ----
def admin_edit_choice(update, context):
    query = update.callback_query
    query.answer()
    if query.from_user.id != ADMIN_ID:
        try: query.answer("Acesso negado", show_alert=True)
        except: pass
        return
    keyboard = []
    for k, v in config['plans'].items():
        keyboard.append([InlineKeyboardButton(f"{v['label']} • {fmt_price(v['price'])}", callback_data=f"edit_{k}")])
    keyboard.append([InlineKeyboardButton("Cancelar", callback_data="admin_cancel")])
    query.message.reply_text("Escolha o plano para editar:", reply_markup=InlineKeyboardMarkup(keyboard))

def admin_edit_start(update, context):
    query = update.callback_query
    query.answer()
    key = query.data.split('_', 1)[1]
    context.user_data['edit_plan_key'] = key
    query.message.reply_text("Envie o novo PREÇO em centavos (ex: 990 para R$9,90) ou envie /skip para não alterar o preço.")
    return EDIT_NEWPRICE

def admin_edit_price(update, context):
    text = update.message.text.strip()
    key = context.user_data.get('edit_plan_key')
    if text.lower() == '/skip':
        context.user_data['new_price'] = None
    else:
        try:
            new_price = int(float(text) if '.' in text else int(text))
            context.user_data['new_price'] = int(new_price)
        except Exception:
            update.message.reply_text("Preço inválido. Envie em centavos (ex: 990) ou /skip")
            return EDIT_NEWPRICE
    update.message.reply_text("Envie a nova validade em dias (ex: 30) ou /skip para manter.")
    return EDIT_NEWDAYS

def admin_edit_days(update, context):
    text = update.message.text.strip()
    if text.lower() == '/skip':
        new_days = None
    else:
        try:
            new_days = int(text)
        except Exception:
            update.message.reply_text("Dias inválidos. Envie um número inteiro (ex: 30) ou /skip")
            return EDIT_NEWDAYS
    key = context.user_data.get('edit_plan_key')
    with charges_lock:
        plan = config['plans'].get(key)
        if not plan:
            update.message.reply_text("Plano não encontrado.")
            return ConversationHandler.END
        if context.user_data.get('new_price') is not None:
            plan['price'] = context.user_data['new_price']
        if new_days is not None:
            plan['days'] = new_days
        config['plans'][key] = plan
        save_json('config.json', config)
    update.message.reply_text("Plano atualizado com sucesso.")
    return ConversationHandler.END

# ---- Adicionar Plano ----
def admin_add_start(update, context):
    query = update.callback_query
    query.answer()
    if query.from_user.id != ADMIN_ID:
        try: query.answer("Acesso negado", show_alert=True)
        except: pass
        return
    query.message.reply_text("Criar novo plano — envie a CHAVE (ex: mensal_1).")
    return ADD_KEY

def admin_add_key(update, context):
    key = update.message.text.strip()
    if not key:
        update.message.reply_text("Chave inválida. Tente novamente.")
        return ADD_KEY
    if key in config['plans']:
        update.message.reply_text("Chave já existe. Escolha outra.")
        return ADD_KEY
    context.user_data['add_key'] = key
    update.message.reply_text("Envie o NOME/label do plano (ex: Mensal Basic).")
    return ADD_LABEL

def admin_add_label(update, context):
    context.user_data['add_label'] = update.message.text.strip()
    update.message.reply_text("Envie o PREÇO em centavos (ex: 990 para R$9,90).")
    return ADD_PRICE

def admin_add_price(update, context):
    text = update.message.text.strip()
    try:
        price = int(float(text) if '.' in text else int(text))
    except Exception:
        update.message.reply_text("Preço inválido. Envie em centavos (ex: 990).")
        return ADD_PRICE
    context.user_data['add_price'] = int(price)
    update.message.reply_text("Envie a validade em DIAS (ex: 30). Envie 0 para vitalício.")
    return ADD_DAYS

def admin_add_days(update, context):
    text = update.message.text.strip()
    try:
        days = int(text)
    except Exception:
        update.message.reply_text("Dias inválidos. Envie um inteiro (ex: 30) ou 0 para vitalício.")
        return ADD_DAYS
    key = context.user_data.get('add_key')
    plan = {
        "label": context.user_data.get('add_label'),
        "price": context.user_data.get('add_price'),
    }
    if days > 0:
        plan['days'] = days
    with charges_lock:
        config['plans'][key] = plan
        save_json('config.json', config)
    update.message.reply_text(f"Plano '{plan['label']}' adicionado com sucesso.")
    return ConversationHandler.END

# ---- Remover Plano ----
def admin_remove_start(update, context):
    query = update.callback_query
    query.answer()
    keyboard = []
    for k, v in config['plans'].items():
        keyboard.append([InlineKeyboardButton(f"{v['label']} • {fmt_price(v['price'])}", callback_data=f"remove_{k}")])
    keyboard.append([InlineKeyboardButton("Cancelar", callback_data="admin_cancel")])
    query.message.reply_text("Escolha o plano para remover:", reply_markup=InlineKeyboardMarkup(keyboard))

def admin_remove_confirm(update, context):
    query = update.callback_query
    query.answer()
    key = query.data.split('_', 1)[1]
    plan = config['plans'].get(key)
    if not plan:
        query.message.reply_text("Plano não encontrado.")
        return ConversationHandler.END
    with charges_lock:
        config['plans'].pop(key, None)
        save_json('config.json', config)
    query.message.reply_text(f"Plano '{plan['label']}' removido com sucesso.")
    return ConversationHandler.END

# ---- Boas-vindas ----
def admin_welcome_start(update, context):
    """Abre o menu de boas-vindas (callback) e inicia a conversação."""
    query = update.callback_query
    try:
        query.answer()
    except:
        pass
    keyboard = [
        [InlineKeyboardButton("Definir Texto", callback_data="welcome_text")],
        [InlineKeyboardButton("Definir Foto/Video", callback_data="welcome_media")],
        [InlineKeyboardButton("Remover Boas-vindas", callback_data="welcome_remove")],
        [InlineKeyboardButton("Cancelar", callback_data="admin_cancel")]
    ]
    try:
        query.message.reply_text("Escolha ação de Boas-vindas:", reply_markup=InlineKeyboardMarkup(keyboard))
    except Exception:
        logging.exception("Erro ao enviar menu de boas-vindas")
    # IMPORTANTE: retorna o estado WELCOME_CHOOSE para ativar o ConversationHandler
    return WELCOME_CHOOSE

def admin_welcome_text_choice(update, context):
    """Inicia fluxo para receber texto de boas-vindas."""
    query = update.callback_query
    try:
        query.answer()
        query.message.reply_text("Envie o texto de boas-vindas (use HTML se quiser).")
    except Exception:
        logging.exception("Erro em admin_welcome_text_choice")
    return WELCOME_TEXT

def admin_welcome_media_choice(update, context):
    """Inicia fluxo para receber mídia (foto/video ou arquivo)."""
    query = update.callback_query
    try:
        query.answer()
        query.message.reply_text("Envie a foto ou vídeo agora. (O bot salvará o file_id)")
    except Exception:
        logging.exception("Erro em admin_welcome_media_choice")
    return WELCOME_UPLOAD

def set_welcome(update, context):
    """Handler único que mantém o que não foi alterado."""
    try:
        # 1) SÓ TEXTO (sem foto/vídeo/documento)
        if update.message.text and not (update.message.photo or update.message.video or update.message.document):
            # Atualiza só o texto no config.json
            config['welcome_text'] = update.message.text_html_urled if update.message.entities else update.message.text
            save_json('config.json', config)
            update.message.reply_text("Texto atualizado! A mídia atual foi mantida.")
            return ConversationHandler.END

        # 2) TEM MÍDIA (foto, vídeo ou documento)
        caption = update.message.caption_html_urled if update.message.caption and update.message.caption_entities else update.message.caption

        if update.message.photo:
            file_id = update.message.photo[-1].file_id
            media_type = 'photo'
        elif update.message.video:
            file_id = update.message.video.file_id
            media_type = 'video'
        elif update.message.document:
            # (mantém teu código de detecção por mime/nome que já tá bom)
            doc = update.message.document
            file_id = doc.file_id
            mt = getattr(doc, 'mime_type', None)
            if mt and mt.startswith('image/'):
                media_type = 'photo'
            elif mt and mt.startswith('video/'):
                media_type = 'video'
            else:
                fname = (getattr(doc, 'file_name', '') or '').lower()
                if any(x in fname for x in ('.jpg', '.jpeg', '.png', '.webp', '.gif')):
                    media_type = 'photo'
                elif any(x in fname for x in ('.mp4', '.mov', '.mkv', '.webm', '.3gp')):
                    media_type = 'video'
                else:
                    update.message.reply_text("Arquivo inválido. Envie foto ou vídeo.")
                    return WELCOME_UPLOAD
        else:
            update.message.reply_text("Envie uma foto ou vídeo.")
            return WELCOME_UPLOAD

        # SALVA A MÍDIA
        welcome['type'] = media_type
        welcome['file_id'] = file_id

        # Se veio caption → atualiza o texto também, senão mantém o antigo
        if caption:
            welcome['caption'] = caption
            config['welcome_text'] = caption
            save_json('config.json', config)
        else:
            # mantém a caption antiga que já estava no welcome.json
            pass

        save_json('welcome.json', welcome)
        update.message.reply_text("Foto/vídeo atualizado! Texto mantido (ou atualizado se veio legenda).")
        return ConversationHandler.END

    except Exception as e:
        logging.exception(f"Erro em set_welcome: {e}")
        update.message.reply_text("Erro ao salvar. Tente novamente.")
        return WELCOME_UPLOAD

def admin_welcome_remove(update, context):
    query = update.callback_query
    try:
        query.answer()
    except:
        pass
    welcome['type'] = None
    welcome['file_id'] = None
    welcome['caption'] = None
    save_json('welcome.json', welcome)
    try:
        query.message.reply_text("Boas-vindas removida.")
    except:
        pass
    return ConversationHandler.END

# ---- Remarketing ----
def admin_remarket_start(update, context):
    query = update.callback_query
    query.answer()
    current_minutes = config.get('remarket_minutes', 30)
    current_msg = config.get('remarket_message', "Ei! Ainda tá pensando no plano? Posso reenviar o Pix rapidinho 😊")
    query.message.reply_text(f"Remarketing atual: {current_minutes} minutos\nMensagem:\n{current_msg}\n\nEnvie o novo tempo em minutos (ex: 30).")
    return REMARKET_TIME

def admin_remarket_time(update, context):
    text = update.message.text.strip()
    try:
        minutes = int(text)
        config['remarket_minutes'] = minutes
    except Exception:
        update.message.reply_text("Valor inválido. Envie o número de minutos.")
        return REMARKET_TIME
    save_json('config.json', config)
    update.message.reply_text("Agora envie a nova mensagem de remarketing (use HTML se quiser).")
    return REMARKET_MESSAGE

def admin_remarket_message(update, context):
    text = update.message.text or ""
    config['remarket_message'] = text
    save_json('config.json', config)
    update.message.reply_text("Configuração de remarketing atualizada.")
    return ConversationHandler.END

# ---- Assinantes ----
def admin_subs_start(update, context):
    query = update.callback_query
    try:
        query.answer()
    except Exception:
        pass

    if query.from_user.id != ADMIN_ID:
        try:
            query.answer("Acesso negado", show_alert=True)
        except:
            pass
        return ConversationHandler.END

    with charges_lock:
        paid_items = [c for c in charges if c.get('paid')]

    if not paid_items:
        try:
            query.message.reply_text("Nenhuma venda paga registrada.")
        except:
            pass
        return ConversationHandler.END

    def _paid_time(c):
        return c.get('paid_at') or c.get('created_at') or 0

    paid_items = sorted(paid_items, key=_paid_time, reverse=True)[:100]

    lines = []
    for c in paid_items:
        tg_id = c.get('tg_id')
        user_repr = str(tg_id)
        try:
            chat = context.bot.get_chat(tg_id)
            uname = getattr(chat, 'username', None)
            if uname:
                user_repr = f"@{uname}"
            else:
                first = getattr(chat, 'first_name', '') or ''
                last = getattr(chat, 'last_name', '') or ''
                name = (first + ' ' + last).strip()
                user_repr = name if name else str(tg_id)
        except Exception:
            user_repr = str(tg_id)

        plan = c.get('plan_label') or c.get('plan_key') or "Plano"
        price = fmt_price(c.get('price', 0))
        paid_ts = c.get('paid_at') or c.get('created_at') or 0
        paid_str = datetime.fromtimestamp(paid_ts).strftime('%d/%m/%Y %H:%M')
        expires = c.get('expires_at')
        expires_str = datetime.fromtimestamp(expires).strftime('%d/%m/%Y') if expires else "—"

        lines.append(f"✅ {user_repr} — {plan} — {price} — {paid_str} — {expires_str}")

    summary = "Últimos assinantes (mostrando até 100):\n\n" + "\n".join(lines)

    try:
        if len(summary) <= 3900:
            query.message.reply_text(summary)
        else:
            bio = io.BytesIO()
            bio.write(summary.encode('utf-8'))
            bio.seek(0)
            query.message.reply_document(document=InputFile(bio, filename="assinantes.txt"), caption="Lista de assinantes (arquivo)")
    except Exception:
        logging.exception("Erro ao enviar lista de assinantes")
    return ConversationHandler.END

# ---- Cancel ----
def admin_cancel(update, context):
    if update.callback_query:
        try:
            update.callback_query.answer()
        except:
            pass
        try:
            update.callback_query.message.reply_text("Operação cancelada.")
        except:
            pass
    else:
        try:
            update.message.reply_text("Operação cancelada.")
        except:
            pass
    return ConversationHandler.END

# =============== ADMIN ROUTES: callback dispatcher  ===============
def admin_callback_router(update, context):
    query = update.callback_query
    data = query.data
    if not data.startswith("admin_") and not data.startswith(("edit_", "remove_")) and not data.startswith(("welcome_",)):
        return
    if data == "admin_edit":
        return admin_edit_choice(update, context)
    if data.startswith("edit_"):
        return admin_edit_start(update, context)
    if data == "admin_add":
        return admin_add_start(update, context)
    if data == "admin_remove":
        return admin_remove_start(update, context)
    if data.startswith("remove_"):
        return admin_remove_confirm(update, context)
    if data == "admin_welcome":
        return admin_welcome_start(update, context)
    if data == "welcome_text":
        return admin_welcome_text_choice(update, context)
    if data == "welcome_media":
        return admin_welcome_media_choice(update, context)
    if data == "welcome_remove":
        return admin_welcome_remove(update, context)
    if data == "admin_remarket":
        return admin_remarket_start(update, context)
    if data == "admin_subs":
        return admin_subs_start(update, context)
    if data == "admin_cancel":
        return admin_cancel(update, context)
    try:
        query.answer()
    except:
        pass

# =============== ADMIN Conversation Handlers registration helper ===============
def build_admin_handlers(dp):
    conv_edit = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_edit_choice, pattern='^admin_edit$'),
                      CallbackQueryHandler(admin_edit_start, pattern='^edit_')],
        states={
            EDIT_NEWPRICE: [MessageHandler(Filters.text & ~Filters.command, admin_edit_price)],
            EDIT_NEWDAYS: [MessageHandler(Filters.text & ~Filters.command, admin_edit_days)]
        },
        fallbacks=[CallbackQueryHandler(admin_cancel, pattern='^admin_cancel$'), CommandHandler('cancel', admin_cancel)],
        allow_reentry=True
    )

    conv_add = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_add_start, pattern='^admin_add$')],
        states={
            ADD_KEY: [MessageHandler(Filters.text & ~Filters.command, admin_add_key)],
            ADD_LABEL: [MessageHandler(Filters.text & ~Filters.command, admin_add_label)],
            ADD_PRICE: [MessageHandler(Filters.text & ~Filters.command, admin_add_price)],
            ADD_DAYS: [MessageHandler(Filters.text & ~Filters.command, admin_add_days)]
        },
        fallbacks=[CallbackQueryHandler(admin_cancel, pattern='^admin_cancel$'), CommandHandler('cancel', admin_cancel)],
        allow_reentry=True
    )

    conv_remove = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_remove_start, pattern='^admin_remove$'),
                      CallbackQueryHandler(admin_remove_confirm, pattern='^remove_')],
        states={},
        fallbacks=[CallbackQueryHandler(admin_cancel, pattern='^admin_cancel$')],
        allow_reentry=True
    )

    conv_welcome = ConversationHandler(
    entry_points=[CallbackQueryHandler(admin_welcome_start, pattern='^admin_welcome$')],
    states={
        # primeiro o estado de escolha: pega os callbacks dos botões do menu
        WELCOME_CHOOSE: [
            CallbackQueryHandler(admin_welcome_text_choice, pattern='^welcome_text$'),
            CallbackQueryHandler(admin_welcome_media_choice, pattern='^welcome_media$'),
            CallbackQueryHandler(admin_welcome_remove, pattern='^welcome_remove$'),
            CallbackQueryHandler(admin_cancel, pattern='^admin_cancel$'),
        ],
        # quando o admin escolhe texto, o próximo message é tratado por set_welcome
        WELCOME_TEXT: [
            MessageHandler(Filters.text & ~Filters.command, set_welcome),
            CallbackQueryHandler(admin_cancel, pattern='^admin_cancel$'),
        ],
        # quando o admin escolhe mídia, aceita foto, vídeo e também arquivos enviados como document
        WELCOME_UPLOAD: [
            MessageHandler(Filters.photo | Filters.video | Filters.document, set_welcome),
            MessageHandler(Filters.text & ~Filters.command, set_welcome),
            CallbackQueryHandler(admin_cancel, pattern='^admin_cancel$'),
        ],
    },
    fallbacks=[CallbackQueryHandler(admin_cancel, pattern='^admin_cancel$'), CommandHandler('cancel', admin_cancel)],
    allow_reentry=True
)

    conv_remarket = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_remarket_start, pattern='^admin_remarket$')],
        states={
            REMARKET_TIME: [MessageHandler(Filters.text & ~Filters.command, admin_remarket_time)],
            REMARKET_MESSAGE: [MessageHandler(Filters.text & ~Filters.command, admin_remarket_message)]
        },
        fallbacks=[CallbackQueryHandler(admin_cancel, pattern='^admin_cancel$')],
        allow_reentry=True
    )

    return [conv_edit, conv_add, conv_remove, conv_welcome, conv_remarket]

# =============== ADMIN COMMAND ===============
def admin_command(update, context):
    if update.effective_user.id != ADMIN_ID:
        update.message.reply_text("Acesso negado.")
        return
    keyboard = [
        [InlineKeyboardButton("💰 Editar Preços", callback_data="admin_edit")],
        [InlineKeyboardButton("➕ Adicionar Plano", callback_data="admin_add")],
        [InlineKeyboardButton("➖ Remover Plano", callback_data="admin_remove")],
        [InlineKeyboardButton("🎉 Boas-vindas", callback_data="admin_welcome")],
        [InlineKeyboardButton("🚀 Remarketing", callback_data="admin_remarket")],
        [InlineKeyboardButton("👑 Assinantes", callback_data="admin_subs")],
        [InlineKeyboardButton("Cancelar", callback_data="admin_cancel")]
    ]
    update.message.reply_text("Painel Admin — DramaFlix", reply_markup=InlineKeyboardMarkup(keyboard))

# =============== /pagar manual (só admin) ===============
def pagar_teste(update, context):
    if update.effective_user.id != ADMIN_ID: return
    if not context.args: return update.message.reply_text("Uso: /pagar external_id")
    if mark_paid(context.args[0], context.bot):
        update.message.reply_text("Link enviado manualmente!")

# =============== MAIN ===============
def main():
    global updater
    if not TOKEN:
        logging.error("TELEGRAM_TOKEN não definido. Abortando.")
        return

    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher

    # user commands
    dp.add_handler(CommandHandler('start', start))
    dp.add_handler(CommandHandler('suporte', suporte))
    dp.add_handler(CommandHandler('status', status))

    # admin
    dp.add_handler(CommandHandler('admin', admin_command))
    admin_handlers = build_admin_handlers(dp)
    for h in admin_handlers:
        dp.add_handler(h)
    dp.add_handler(CallbackQueryHandler(admin_callback_router, pattern='^(admin_|edit_|remove_|welcome_)'))

    # payment flow
    dp.add_handler(CallbackQueryHandler(callback_plan, pattern='^plan_'))
    dp.add_handler(CallbackQueryHandler(copy_pix_callback, pattern='^copy_pix$'))

    dp.add_handler(CommandHandler('pagar', pagar_teste))

    # threads
    threading.Thread(target=run_flask, daemon=True).start()
    threading.Thread(target=scheduler, args=(updater.bot,), daemon=True).start()

    logging.info("DramaFlix 100% AUTOMÁTICO RODANDO!")
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()